<template>
  <div>
    <h1>App</h1>
    <router-view/>
  </div>
</template>
